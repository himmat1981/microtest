<?php

namespace Drupal\custom_entity\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting Unit summary entity entities.
 *
 * @ingroup custom_entity
 */
class UnitSummaryEntityDeleteForm extends ContentEntityDeleteForm {


}
