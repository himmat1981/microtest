<?php

namespace Drupal\custom_entity\Commands;

use Drush\Commands\DrushCommands;

/**
 * A Drush commandfile.
 *
 * In addition to this file, you need a drush.services.yml
 * in root of your module, and a composer.json file that provides the name
 * of the services file to use.
 */
class CustomEntityCommands extends DrushCommands {
  /**
   *
   *   Argument provided to the drush command.
   * @command custom_entity:custom_entity_create
   * @aliases create-entity
   */
  public function custom_entity_create() {
	$raw_data = array(1 => "label11", 2 => "label21", 3 => "label31", 4 => "label41");
	foreach($raw_data as $key => $value) {
		$data = [
		  'name' => $value,
		  'uid' => $key,
		  'status' => 1,
		  'field_email' => "akash@test.com",
		];
		$unit_summary_entity = \Drupal::entityTypeManager()
		  ->getStorage('unit_summary_entity')
		  ->create($data);
		$unit_summary_entity->save();
	}
  }
}