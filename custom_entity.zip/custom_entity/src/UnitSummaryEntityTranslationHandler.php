<?php

namespace Drupal\custom_entity;

use Drupal\content_translation\ContentTranslationHandler;

/**
 * Defines the translation handler for unit_summary_entity.
 */
class UnitSummaryEntityTranslationHandler extends ContentTranslationHandler {

  // Override here the needed methods from ContentTranslationHandler.
}
