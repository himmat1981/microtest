<?php

namespace Drupal\custom_entity\Entity;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityChangedInterface;
use Drupal\Core\Entity\EntityPublishedInterface;
use Drupal\user\EntityOwnerInterface;

/**
 * Provides an interface for defining Unit summary entity entities.
 *
 * @ingroup custom_entity
 */
interface UnitSummaryEntityInterface extends ContentEntityInterface, EntityChangedInterface, EntityPublishedInterface, EntityOwnerInterface {

  /**
   * Add get/set methods for your configuration properties here.
   */

  /**
   * Gets the Unit summary entity name.
   *
   * @return string
   *   Name of the Unit summary entity.
   */
  public function getName();

  /**
   * Sets the Unit summary entity name.
   *
   * @param string $name
   *   The Unit summary entity name.
   *
   * @return \Drupal\custom_entity\Entity\UnitSummaryEntityInterface
   *   The called Unit summary entity entity.
   */
  public function setName($name);

  /**
   * Gets the Unit summary entity creation timestamp.
   *
   * @return int
   *   Creation timestamp of the Unit summary entity.
   */
  public function getCreatedTime();

  /**
   * Sets the Unit summary entity creation timestamp.
   *
   * @param int $timestamp
   *   The Unit summary entity creation timestamp.
   *
   * @return \Drupal\custom_entity\Entity\UnitSummaryEntityInterface
   *   The called Unit summary entity entity.
   */
  public function setCreatedTime($timestamp);

}
